import React, { useEffect, useRef, useState, useCallback } from 'react';
import Hls from 'hls.js';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Slider } from "@/components/ui/slider";
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, Volume2, VolumeX, Maximize, Minimize, Play, Pause, Clock, Cast, Film 
} from 'lucide-react';

const PlayerPage = () => {
  const videoRef = useRef(null);
  const playerContainerRef = useRef(null);
  const hlsRef = useRef(null);
  const controlsTimeoutRef = useRef(null);
  const videoSrc = "https://kixi.shop/hls/stream.m3u8";
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/f5ea53c9-20fd-4e10-8b49-b3db89fd3a39/a9135715402d980dfee03833e696db42.png";

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true); 
  const [volume, setVolume] = useState(0.5);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showSpeedOptions, setShowSpeedOptions] = useState(false);
  const [isLive, setIsLive] = useState(true); 
  const [bufferLength, setBufferLength] = useState(0);

  const formatTime = (timeInSeconds) => {
    if (!isFinite(timeInSeconds) || timeInSeconds < 0) return '0:00';
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  };

  const handlePlayPause = useCallback(() => {
    if (videoRef.current) {
      if (videoRef.current.paused || videoRef.current.ended) {
        videoRef.current.play().catch(e => console.error("Play error:", e));
      } else {
        videoRef.current.pause();
      }
    }
  }, []);

  const handleMuteToggle = useCallback(() => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(videoRef.current.muted);
      if (!videoRef.current.muted && videoRef.current.volume === 0) {
        videoRef.current.volume = 0.5; 
        setVolume(0.5);
      }
    }
  }, []);

  const handleVolumeChange = useCallback((value) => {
    if (videoRef.current) {
      const newVolume = value[0] / 100;
      videoRef.current.volume = newVolume;
      setVolume(newVolume);
      videoRef.current.muted = newVolume === 0;
      setIsMuted(newVolume === 0);
    }
  }, []);

  const handleTimeUpdate = useCallback(() => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      if (videoRef.current.duration && !isNaN(videoRef.current.duration) && isFinite(videoRef.current.duration)) {
        setDuration(videoRef.current.duration);
        setIsLive(videoRef.current.duration === Infinity);
      } else {
        setIsLive(true); 
      }
      
      let bufferedEnd = 0;
      if (videoRef.current.buffered.length > 0) {
        bufferedEnd = videoRef.current.buffered.end(videoRef.current.buffered.length - 1);
      }
      setBufferLength((bufferedEnd / videoRef.current.duration) * 100);

    }
  }, []);
  
  const handleSeek = useCallback((value) => {
    if (videoRef.current && duration > 0 && isFinite(duration)) {
      const newTime = (value[0] / 100) * duration;
      videoRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  }, [duration]);

  const handleFullScreenToggle = useCallback(() => {
    if (!playerContainerRef.current) return;
    if (!document.fullscreenElement) {
      playerContainerRef.current.requestFullscreen().catch(err => {
        alert(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  }, []);

  const handleShowControls = useCallback(() => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  }, [isPlaying]);

  const handlePlaybackSpeedChange = (speed) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
      setPlaybackSpeed(speed);
      setShowSpeedOptions(false);
    }
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onLoadedMetadata = () => {
      if (video.duration && !isNaN(video.duration) && isFinite(video.duration)) {
        setDuration(video.duration);
        setIsLive(video.duration === Infinity);
      } else {
         setIsLive(true);
      }
      setIsLoading(false);
      video.volume = volume; 
      video.muted = isMuted;
      if (isPlaying || !video.paused) { // Maintain playing state
         video.play().catch(e => console.error("Autoplay error:", e));
      }
    };
    
    const onPlaying = () => { setIsPlaying(true); setIsLoading(false); handleShowControls(); };
    const onPause = () => { setIsPlaying(false); setShowControls(true); }; // Show controls on pause
    const onVolumeChange = () => {
      if(video) {
        setIsMuted(video.muted);
        setVolume(video.volume);
      }
    };
    const onEnded = () => setIsPlaying(false);
    const onWaiting = () => setIsLoading(true);
    const onCanPlay = () => setIsLoading(false);

    video.addEventListener('loadedmetadata', onLoadedMetadata);
    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('pause', onPause);
    video.addEventListener('volumechange', onVolumeChange);
    video.addEventListener('ended', onEnded);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('progress', handleTimeUpdate);


    if (Hls.isSupported()) {
      const hlsConfig = {
        autoStartLoad: true,
        startPosition: -1, 
        debug: false,
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 90, 
        maxBufferLength: 60, 
        maxMaxBufferLength: 120,
        fragLoadingTimeOut: 40000, 
        manifestLoadingTimeOut: 10000,
        levelLoadingTimeOut: 10000,
        liveSyncDurationCount: 3, 
        liveMaxLatencyDurationCount: 5, 
        abrEwmaDefaultEstimate: 500000, 
        abrMaxWithRealBitrate: true,
      };
      const hls = new Hls(hlsConfig);
      hlsRef.current = hls;
      hls.loadSource(videoSrc);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setIsLoading(false);
        if (isMuted) video.muted = true;
        // Try to play, but usually requires user interaction
        video.play().then(() => {
            setIsPlaying(true);
        }).catch(error => {
          console.log("Autoplay prevented, user interaction needed: ", error);
          setIsPlaying(false); 
          setIsLoading(false);
        });
      });
      hls.on(Hls.Events.ERROR, (event, data) => {
        console.error("HLS Error:", data.type, data.details, data);
        setIsLoading(false);
        if (data.fatal) {
          switch(data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.warn("HLS: Network error, retrying load...", data.details);
              if(data.details === "manifestLoadTimeOut" || data.details === "fragLoadTimeOut") {
                 hls.startLoad();
              } else {
                 hls.loadSource(videoSrc); 
              }
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.warn("HLS: Media error, attempting to recover...", data.details);
              hls.recoverMediaError();
              break;
            default:
              console.error("HLS: Unrecoverable fatal error", data);
              hls.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = videoSrc;
       video.addEventListener('loadedmetadata', () => {
        setIsLoading(false);
        if (isMuted) video.muted = true;
        video.play().then(() => {
          setIsPlaying(true);
        }).catch(error => {
          console.log("Autoplay prevented for HLS native: ", error);
          setIsPlaying(false);
          setIsLoading(false);
        });
      });
    } else {
      setIsLoading(false);
      console.error("HLS is not supported in this browser.");
    }
    
    handleShowControls(); // Initial call to show controls

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
      }
      if (video) {
        video.removeEventListener('loadedmetadata', onLoadedMetadata);
        video.removeEventListener('timeupdate', handleTimeUpdate);
        video.removeEventListener('playing', onPlaying);
        video.removeEventListener('pause', onPause);
        video.removeEventListener('volumechange', onVolumeChange);
        video.removeEventListener('ended', onEnded);
        video.removeEventListener('waiting', onWaiting);
        video.removeEventListener('canplay', onCanPlay);
        video.removeEventListener('progress', handleTimeUpdate);
      }
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [videoSrc, handleTimeUpdate, handleShowControls, isMuted, volume]); // Removed isPlaying from deps to avoid loop

  useEffect(() => {
    const handleFullScreenChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullScreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullScreenChange);
  }, []);


  return (
    <motion.div 
      className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 text-white flex flex-col items-center justify-center p-0 md:p-4 relative overflow-hidden select-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="absolute top-0 left-0 w-full h-full hero-bg opacity-20 z-0"></div>
      
      <motion.div 
        ref={playerContainerRef}
        className="w-full max-w-5xl z-10 aspect-video relative bg-black rounded-none md:rounded-xl shadow-2xl overflow-hidden border-0 md:border-2 border-purple-500/30 neon-glow"
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.6, type: "spring", stiffness: 100 }}
        onMouseMove={handleShowControls}
        onMouseLeave={() => { if (isPlaying && !showSpeedOptions) setShowControls(false); }}
        onClick={(e) => { 
          if (e.target === e.currentTarget || e.target === videoRef.current) {
            handlePlayPause();
          }
          handleShowControls();
        }}
      >
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          playsInline
          autoPlay={false}
          muted={isMuted}
        >
          عذرًا، متصفحك لا يدعم تشغيل الفيديو.
        </video>

        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-30 pointer-events-none">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            >
              <Film className="w-12 h-12 md:w-16 md:h-16 text-purple-400" />
            </motion.div>
          </div>
        )}

        <AnimatePresence>
          {showControls && (
            <motion.div 
              className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-20 flex flex-col justify-between p-2 md:p-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()} 
            >
              <div className="flex justify-between items-start">
                <Link to="/" onClick={(e) => e.stopPropagation()}>
                  <Button variant="ghost" size="icon" className="text-slate-200 hover:text-white hover:bg-white/10 transition-colors rounded-full w-10 h-10 md:w-12 md:h-12">
                    <ArrowLeft className="h-5 w-5 md:h-6 md:w-6" />
                  </Button>
                </Link>
                <div className="flex flex-col items-end space-y-1">
                  {isLive && (
                    <div className="live-indicator px-2 py-1 text-xs font-semibold rounded-full flex items-center space-x-1">
                      <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                      <span>مباشر</span>
                    </div>
                  )}
                  <img  alt="KIXI Mini Logo" className="w-20 h-auto md:w-24 hidden sm:block" src={logoUrl} />
                </div>
              </div>

              <div 
                className="absolute inset-0 flex items-center justify-center pointer-events-none"
                
              >
                {!isPlaying && !isLoading && (
                   <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={(e) => { e.stopPropagation(); handlePlayPause(); }}
                    className="text-white bg-white/10 hover:bg-white/20 rounded-full w-16 h-16 md:w-20 md:h-20 pointer-events-auto"
                  >
                    <Play className="h-8 w-8 md:h-10 md:w-10 fill-white ml-1" />
                  </Button>
                )}
              </div>

              <div className="space-y-1 md:space-y-2">
                <div className="relative w-full h-1.5 md:h-2 player-slider-container">
                   <Slider
                    value={[isLive || duration === 0 ? 100 : (currentTime / duration) * 100]}
                    max={100}
                    step={0.1}
                    onValueChange={handleSeek}
                    className="w-full player-slider"
                    aria-label=" شريط التقدم"
                    disabled={isLive}
                  />
                   <div 
                    className="absolute top-0 left-0 h-full bg-purple-400/40 rounded-full player-buffer-progress" 
                    style={{ width: `${isLive ? 100 : bufferLength}%`}}
                  ></div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-1 md:space-x-2">
                    <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); handlePlayPause(); }} className="text-slate-200 hover:text-white">
                      {isPlaying ? <Pause className="h-5 w-5 md:h-6 md:w-6" /> : <Play className="h-5 w-5 md:h-6 md:w-6" />}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); handleMuteToggle(); }} className="text-slate-200 hover:text-white">
                      {isMuted || volume === 0 ? <VolumeX className="h-5 w-5 md:h-6 md:w-6" /> : <Volume2 className="h-5 w-5 md:h-6 md:w-6" />}
                    </Button>
                    <Slider 
                      value={[volume * 100]} 
                      max={100} 
                      step={1} 
                      onValueChange={handleVolumeChange} 
                      className="w-16 md:w-24 player-slider-volume"
                      aria-label="مستوى الصوت"
                      onClick={(e) => e.stopPropagation()}
                    />
                     <span className="text-xs md:text-sm text-slate-300 w-20 text-left">{formatTime(currentTime)} / {isLive ? "مباشر" : formatTime(duration)}</span>
                  </div>
                  <div className="flex items-center space-x-1 md:space-x-2">
                    <div className="relative">
                      <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); setShowSpeedOptions(!showSpeedOptions);}} className="text-slate-200 hover:text-white">
                        <Clock className="h-5 w-5 md:h-6 md:w-6" />
                      </Button>
                      <AnimatePresence>
                      {showSpeedOptions && (
                        <motion.div 
                          className="absolute bottom-full right-0 mb-2 bg-slate-900/80 backdrop-blur-md rounded-md p-1.5 shadow-xl border border-slate-700/50"
                          initial={{ opacity: 0, y: 10, scale:0.95 }}
                          animate={{ opacity: 1, y: 0, scale:1 }}
                          exit={{ opacity: 0, y: 10, scale:0.95 }}
                          onClick={(e) => e.stopPropagation()}
                        >
                          {[0.5, 0.75, 1, 1.25, 1.5, 2].map(speed => (
                            <Button 
                              key={speed} 
                              variant="ghost" 
                              size="sm"
                              className={`w-full justify-center text-xs px-3 py-1.5 h-auto ${playbackSpeed === speed ? 'bg-purple-600/50 text-purple-300 font-bold' : 'text-slate-200 hover:bg-slate-700/70 hover:text-white'}`}
                              onClick={() => handlePlaybackSpeedChange(speed)}
                            >
                              {speed}x
                            </Button>
                          ))}
                        </motion.div>
                      )}
                      </AnimatePresence>
                    </div>
                    <Button variant="ghost" size="icon" className="text-slate-200 hover:text-white">
                      <Cast className="h-5 w-5 md:h-6 md:w-6" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); handleFullScreenToggle(); }} className="text-slate-200 hover:text-white">
                      {isFullScreen ? <Minimize className="h-5 w-5 md:h-6 md:w-6" /> : <Maximize className="h-5 w-5 md:h-6 md:w-6" />}
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
        
      <motion.div 
        className="mt-4 md:mt-6 p-4 md:p-6 glass-effect rounded-xl shadow-lg w-full max-w-5xl z-10"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.5 }}
      >
        <h2 className="text-xl md:text-2xl font-semibold mb-2 md:mb-3 gradient-text">تفاصيل البث</h2>
        <p className="text-slate-300 text-sm md:text-md leading-relaxed">
          أنت تشاهد الآن بث مباشر لمباراة كرة قدم مثيرة على KIXI. استمتع بتجربة مشاهدة فريدة بجودة عالية وبدون انقطاع.
          لا تنسَ تفقد جدول المباريات القادمة!
        </p>
      </motion.div>
    </motion.div>
  );
};

export default PlayerPage;
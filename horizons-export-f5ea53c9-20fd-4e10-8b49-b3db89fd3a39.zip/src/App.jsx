import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Toaster } from "@/components/ui/toaster";
import { Button } from "@/components/ui/button";
import { PlayCircle, Zap, Tv, CalendarDays } from 'lucide-react';
import PlayerPage from '@/pages/PlayerPage';
import { motion } from 'framer-motion';

const HomePage = () => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/f5ea53c9-20fd-4e10-8b49-b3db89fd3a39/a9135715402d980dfee03833e696db42.png";
  return (
    <div className="min-h-screen hero-bg text-white flex flex-col items-center justify-center p-4 overflow-hidden">
      <motion.header 
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="text-center mb-12"
      >
        <motion.div 
          className="inline-block p-1 rounded-lg bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 mb-6 floating-animation"
          whileHover={{ scale: 1.1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          <div className="bg-slate-900 p-4 rounded-md shadow-2xl">
            <img  
              alt="KIXI Logo" 
              className="w-48 h-auto md:w-64 object-contain"
             src={logoUrl} />
          </div>
        </motion.div>
        <h1 className="text-6xl md:text-7xl font-black tracking-tight gradient-text hidden">
          KIXI
        </h1>
        <p className="mt-4 text-xl md:text-2xl text-slate-300 max-w-2xl mx-auto">
          تجربة مشاهدة مباريات كرة القدم المثالية. بث مباشر عالي الجودة، بدون تقطيع، في أي وقت ومن أي مكان!
        </p>
      </motion.header>

      <motion.main 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
        className="text-center mb-12"
      >
        <Link to="/play">
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 hover:from-purple-700 hover:via-pink-600 hover:to-orange-500 text-white font-bold text-xl py-8 px-12 rounded-full shadow-xl transform transition-all duration-300 hover:scale-105 pulse-glow"
          >
            <PlayCircle className="mr-3 h-8 w-8" />
            شاهد الآن!
          </Button>
        </Link>
      </motion.main>

      <motion.section 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 max-w-5xl w-full"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ staggerChildren: 0.2, delayChildren: 0.5 }}
      >
        {[
          { icon: <Zap className="w-10 h-10 text-purple-400" />, title: "بث فائق السرعة", description: "استمتع بمشاهدة بدون تقطيع مع أحدث تقنيات البث." },
          { icon: <Tv className="w-10 h-10 text-pink-400" />, title: "جودة عالية HD", description: "شاهد المباريات بوضوح لا مثيل له وتفاصيل دقيقة." },
          { icon: <CalendarDays className="w-10 h-10 text-orange-400" />, title: "تغطية شاملة", description: "أهم الدوريات والبطولات العالمية بين يديك." },
        ].map((feature, index) => (
          <motion.div 
            key={index}
            className="stats-card p-6 rounded-2xl text-center shadow-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            whileHover={{ y: -5, boxShadow: "0 10px 20px rgba(0,0,0,0.2)" }}
          >
            <div className="mb-4 flex justify-center">{feature.icon}</div>
            <h3 className="text-2xl font-semibold mb-2 gradient-text">{feature.title}</h3>
            <p className="text-slate-400 text-sm">{feature.description}</p>
          </motion.div>
        ))}
      </motion.section>

      <motion.footer 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8, ease: "easeOut" }}
        className="mt-16 text-center text-slate-400"
      >
        <p>&copy; {new Date().getFullYear()} KIXI. جميع الحقوق محفوظة.</p>
        <p className="text-sm">
          صُمم بشغف بواسطة <span className="gradient-text font-semibold">Hostinger Horizons</span>
        </p>
      </motion.footer>
      <Toaster />
    </div>
  );
};

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/play" element={<PlayerPage />} />
      </Routes>
    </Router>
  );
}

export default App;